Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_front", "pdth_hit_feedback_front", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_fr")
end)

Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_back", "pdth_hit_feedback_back", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_bck")
end)

Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_right", "pdth_hit_feedback_right", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_r")
end)

Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_left", "pdth_hit_feedback_left", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_l")
end)

Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_up", "pdth_hit_feedback_up", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_fr")
end)

Hooks:PostHook(CoreEnvironmentControllerManager, "hit_feedback_down", "pdth_hit_feedback_down", function(self)
	managers.hud:effect_screen(1, { 0.98, 0.48, 0.29 }, "screen_hit_bck")
end)