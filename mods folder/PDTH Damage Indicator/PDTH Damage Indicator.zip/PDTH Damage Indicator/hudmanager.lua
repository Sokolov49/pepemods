-- Various screen effects setup
Hooks:PostHook(HUDManager, "init_finalize", "init_finalize_pdth_screen_effect", function(self)
    local hud = self:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	self._screen_hit_fr_panel = hud.panel:bitmap({
        name = "screen_hit_fr_panel",
        visible = true,
        texture = "guis/textures/pd2/screen_hit_fr",
        layer = 1,
        color = Color(0.75, 0.75, 0.75),
        alpha = 0,
        blend_mode = "add",
        w = hud.panel:w(),
        h = hud.panel:h(),
        x = 0,
        y = 0 
    })
	self._screen_hit_bck_panel = hud.panel:bitmap({
        name = "screen_hit_fr_panel",
        visible = true,
        texture = "guis/textures/pd2/screen_hit_bck",
        layer = 1,
        color = Color(0.75, 0.75, 0.75),
        alpha = 0,
        blend_mode = "add",
        w = hud.panel:w(),
        h = hud.panel:h(),
        x = 0,
        y = 0 
    })
	self._screen_hit_l_panel = hud.panel:bitmap({
        name = "screen_hit_fr_panel",
        visible = true,
        texture = "guis/textures/pd2/screen_hit_l",
        layer = 1,
        color = Color(0.75, 0.75, 0.75),
        alpha = 0,
        blend_mode = "add",
        w = hud.panel:w(),
        h = hud.panel:h(),
        x = 0,
        y = 0 
    })
	self._screen_hit_r_panel = hud.panel:bitmap({
        name = "screen_hit_fr_panel",
        visible = true,
        texture = "guis/textures/pd2/screen_hit_r",
        layer = 1,
        color = Color(0.75, 0.75, 0.75),
        alpha = 0,
        blend_mode = "add",
        w = hud.panel:w(),
        h = hud.panel:h(),
        x = 0,
        y = 0 
    })
end)

-- Screen effect functions
-- Helper function
function HUDManager:effect_screen(duration, color, effect_name)
	if effect_name == nil then
		effect_name = "screen_hit_fr"
	end
		
	if effect_name == "screen_hit_fr" then
		self:_do_effect_screen_hit_fr_panel(duration, color)
	elseif effect_name == "screen_hit_bck" then
		self:_do_effect_screen_hit_bck_panel(duration, color)
	elseif effect_name == "screen_hit_l" then
		self:_do_effect_screen_hit_l_panel(duration, color)
	elseif effect_name == "screen_hit_r" then
		self:_do_effect_screen_hit_r_panel(duration, color)
	end
end

-- PDTH Stuff
function HUDManager:_do_effect_screen_hit_fr_panel(duration, color)	
	if not _G.is_vr then
		self._screen_hit_fr_panel:set_alpha(1)
		self._screen_hit_fr_panel_duration = duration
		self._screen_hit_fr_panel:set_color(Color(color[1], color[2], color[3]))
		if self._screen_hit_fr_panel_active then
			self._screen_hit_fr_panel:stop()
		end
		self._screen_hit_fr_panel_active = true
		self._screen_hit_fr_panel:animate(callback(self, self, "_fadeout_effect_screen_hit_fr_panel"))
	end
end

function HUDManager:_do_effect_screen_hit_bck_panel(duration, color)	
	if not _G.is_vr then
		self._screen_hit_bck_panel:set_alpha(1)
		self._screen_hit_bck_panel_duration = duration
		self._screen_hit_bck_panel:set_color(Color(color[1], color[2], color[3]))
		if self._screen_hit_bck_panel_active then
			self._screen_hit_bck_panel:stop()
		end
		self._screen_hit_bck_panel_active = true
		self._screen_hit_bck_panel:animate(callback(self, self, "_fadeout_effect_screen_hit_bck_panel"))
	end
end

function HUDManager:_do_effect_screen_hit_l_panel(duration, color)	
	if not _G.is_vr then
		self._screen_hit_l_panel:set_alpha(1)
		self._screen_hit_l_panel_duration = duration
		self._screen_hit_l_panel:set_color(Color(color[1], color[2], color[3]))
		if self._screen_hit_l_panel_active then
			self._screen_hit_l_panel:stop()
		end
		self._screen_hit_l_panel_active = true
		self._screen_hit_l_panel:animate(callback(self, self, "_fadeout_effect_screen_hit_l_panel"))
	end
end

function HUDManager:_do_effect_screen_hit_r_panel(duration, color)	
	if not _G.is_vr then
		self._screen_hit_r_panel:set_alpha(1)
		self._screen_hit_r_panel_duration = duration
		self._screen_hit_r_panel:set_color(Color(color[1], color[2], color[3]))
		if self._screen_hit_r_panel_active then
			self._screen_hit_r_panel:stop()
		end
		self._screen_hit_r_panel_active = true
		self._screen_hit_r_panel:animate(callback(self, self, "_fadeout_effect_screen_hit_r_panel"))
	end
end

function HUDManager:_fadeout_effect_screen_hit_fr_panel()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._screen_hit_fr_panel_duration do
		curr_time = Application:time()
		self._screen_hit_fr_panel:set_alpha(1 - ((curr_time - start_time) / self._screen_hit_fr_panel_duration))
		coroutine.yield()
	end
	self._screen_hit_fr_panel:set_alpha(0)
	self._screen_hit_fr_panel_active = false
end

function HUDManager:_fadeout_effect_screen_hit_bck_panel()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._screen_hit_bck_panel_duration do
		curr_time = Application:time()
		self._screen_hit_bck_panel:set_alpha(1 - ((curr_time - start_time) / self._screen_hit_bck_panel_duration))
		coroutine.yield()
	end
	self._screen_hit_bck_panel:set_alpha(0)
	self._screen_hit_bck_panel_active = false
end

function HUDManager:_fadeout_effect_screen_hit_l_panel()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._screen_hit_l_panel_duration do
		curr_time = Application:time()
		self._screen_hit_l_panel:set_alpha(1 - ((curr_time - start_time) / self._screen_hit_l_panel_duration))
		coroutine.yield()
	end
	self._screen_hit_l_panel:set_alpha(0)
	self._screen_hit_l_panel_active = false
end

function HUDManager:_fadeout_effect_screen_hit_r_panel()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._screen_hit_r_panel_duration do
		curr_time = Application:time()
		self._screen_hit_r_panel:set_alpha(1 - ((curr_time - start_time) / self._screen_hit_r_panel_duration))
		coroutine.yield()
	end
	self._screen_hit_r_panel:set_alpha(0)
	self._screen_hit_r_panel_active = false
end