Hooks:PostHook(PlayerTweakData, "init", "InstaMask", function(self, tweak_data)
	self.put_on_mask_time = 0
end)