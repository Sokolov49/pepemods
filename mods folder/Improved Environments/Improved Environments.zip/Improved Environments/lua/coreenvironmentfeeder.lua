core:import("CoreClass")

Feeder = Feeder or CoreClass.class()
Feeder.APPLY_GROUP_ID = 0
Feeder.DATA_PATH_KEY = nil
Feeder.IS_GLOBAL = nil
Feeder.AFFECTED_LIST = nil
Feeder.DEFAULT_VALUE = nil
Feeder.FILTER_CATEGORY = "Others"

PostEffectBloomIntensityFeeder = PostEffectBloomIntensityFeeder or CoreClass.class(Feeder)
PostEffectBloomIntensityFeeder.DATA_PATH_KEY = Idstring("post_effect/bloom_combine_post_processor/bloom_combine/bloom_lense/bloom_intensity"):key()
PostEffectBloomIntensityFeeder.IS_GLOBAL = nil
PostEffectBloomIntensityFeeder.DEFAULT_VALUE = 0.5
PostEffectBloomIntensityFeeder.FILTER_CATEGORY = "Effect"

function PostEffectBloomIntensityFeeder:apply(handler, viewport, scene)
	local material = handler:_get_post_processor_modifier_material(viewport, scene, ids_bloom_lense_id, ids_bloom_combine_processor, ids_bloom_combine, ids_bloom_lense)

	material:set_variable(0, 0)
end