Hooks:PostHook(CoreEnvironmentControllerManager, "init", "post_env", function(self)
	self._base_contrast = 0
end)