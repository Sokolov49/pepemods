local data = BlackMarketTweakData._init_player_styles
function BlackMarketTweakData:_init_player_styles(tweak_data)
    data(self, tweak_data)
	local body_replacement_with_armour = {
		head = false,
		armor = false,
		body = true,
		hands = true,
		vest = true
	}
	local wild_body_replacement_with_armour = {
		head = false,
		armor = false,
		body = true,
		hands = false,
		vest = true
	}
	local body_replacement_with_allarmour = {
		head = false,
		armor = false,
		body = true,
		hands = true,
		vest = false
	}
	local body_replacement_with_lbvarmour = {
		head = false,
		armor = true,
		body = true,
		hands = true,
		vest = false
	} 
		
	self.player_styles.tux.body_replacement = body_replacement_with_armour
	self.player_styles.tux.characters.wild.third_body_replacement = wild_body_replacement_with_armour
	self.player_styles.tux.third_body_replacement = self.player_styles.tux.body_replacement
	self.player_styles.poolrepair.body_replacement = body_replacement_with_armour
	self.player_styles.poolrepair.third_body_replacement = body_replacement_with_armour
	self.player_styles.xmas_tuxedo.characters.wild.third_body_replacement = wild_body_replacement_with_armour
	self.player_styles.xmas_tuxedo.body_replacement = body_replacement_with_armour
	self.player_styles.xmas_tuxedo.third_body_replacement = body_replacement_with_armour
	self.player_styles.punk.body_replacement = body_replacement_with_armour
	self.player_styles.punk.third_body_replacement = body_replacement_with_armour
	self.player_styles.sneak_suit.body_replacement = body_replacement_with_armour
	self.player_styles.sneak_suit.third_body_replacement = body_replacement_with_armour
	self.player_styles.slaughterhouse.body_replacement = body_replacement_with_armour
	self.player_styles.slaughterhouse.third_body_replacement = body_replacement_with_armour
	self.player_styles.hippie.body_replacement = body_replacement_with_armour
	self.player_styles.hippie.third_body_replacement = body_replacement_with_armour
	self.player_styles.t800.body_replacement = body_replacement_with_armour
	self.player_styles.t800.third_body_replacement = body_replacement_with_armour
	self.player_styles.peacoat.body_replacement = body_replacement_with_armour
	self.player_styles.peacoat.third_body_replacement = body_replacement_with_armour
	self.player_styles.leather.body_replacement = body_replacement_with_armour
	self.player_styles.leather.third_body_replacement = body_replacement_with_armour
	self.player_styles.thug.body_replacement = body_replacement_with_allarmour
	self.player_styles.thug.third_body_replacement = body_replacement_with_allarmour
	self.player_styles.traditional.body_replacement = body_replacement_with_armour
	self.player_styles.traditional.third_body_replacement = body_replacement_with_armour
	self.player_styles.general.body_replacement = body_replacement_with_armour
	self.player_styles.general.third_body_replacement = body_replacement_with_armour
end