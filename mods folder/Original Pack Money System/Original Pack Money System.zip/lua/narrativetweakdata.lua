local data = NarrativeTweakData.init
function NarrativeTweakData:init(tweak_data)
	data(self, tweak_data)
	
	self.STARS[1] = {jcs = {50, 40, 30, 20, 10 }} -- OK
	self.STARS[2] = {jcs = {70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[3] = {jcs = {80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[4] = {jcs = {90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[5] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[6] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[7] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[8] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[9] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.STARS[10] = {jcs = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10 }} -- OK
	self.HEATED_MAX_XP_MUL = 1.5
	self.FREEZING_MAX_XP_MUL = 0
	self.DEFAULT_HEAT = {this_job = -15, other_jobs = 10}

	self.jobs.arena.payout = {12800}
	self.jobs.rvd.payout = {19000}
	self.jobs.rvd_pro.payout = {21000}
	
	self.jobs.roberts.payout = {26000}
	self.jobs.rat.payout = {4000}
	self.jobs.jolly.payout = {48000}
	self.jobs.peta.payout = {128000}
	self.jobs.peta_pro.payout = {152000}
	self.jobs.moon.payout = {36000}
	self.jobs.alex_pro.payout = {20000}
	self.jobs.firestarter.payout = {34000}
	self.jobs.watchdogs.payout = {10000}
	self.jobs.watchdogs_night.payout = {10000}
	self.jobs.watchdogs_wrapper.payout = {10000}
	self.jobs.mia_pro.payout = {25000}
	self.jobs.hox.payout = {125000}
	self.jobs.hox_pro.payout = {145000}
	self.jobs.big.payout = {12000}
	self.jobs.mad.payout = {80000}
	self.jobs.man.payout = {89000}
	self.jobs.pal.payout = {81000}
	self.jobs.dinner.payout = {54000}
	self.jobs.spa.payout = {112000}
	self.jobs.pbr2.payout = {46000}
	self.jobs.sah.payout = {26000}
	self.jobs.vit.payout = {246000}
	self.jobs.vit.payout = {246000}
	self.jobs.friend.payout = {52000}
	self.jobs.election_day_pro.payout = {25000}
	self.jobs.born.payout = {54000}
	self.jobs.born_pro.payout = {59000}
	self.jobs.red2.payout = {13000}
	self.jobs.fish.payout = {17000}
	self.jobs.dah.payout = {5000}
	
	math.randomseed(os.date("%d") * 1000)
		
	local rand = {true, false, false, false, false}
	
	self.jobs.cage.jc = 50
	self.jobs.arena.jc = 40
	self.jobs.roberts.jc = 50
	self.jobs.rvd.jc = 40
	self.jobs.family.jc = 20
	self.jobs.branchbank_pro.jc = 10
	self.jobs.kosugi.jc = 10
	self.jobs.arm_cro_single.jc = 50
	self.jobs.arm_fac_single.jc = 40
	self.jobs.arm_hcm_single.jc = 50
	self.jobs.arm_par_single.jc = 40
	self.jobs.arm_und_single.jc = 40

	self.jobs.mallcrasher.jc = 40
	self.jobs.cane.jc = 30
	self.jobs.nightclub.jc = 20
	self.jobs.jolly.jc = 40
	self.jobs.peta.jc = 50
	self.jobs.pines.jc = 30
	self.jobs.moon.jc = 20
	self.jobs.ukrainian_job_prof.jc = 20
	self.jobs.four_stores.jc = 10
	self.jobs.shoutout_raid.jc = 50
	self.jobs.fex.jc = 50
	
	self.jobs.alex.jc = 50
	self.jobs.firestarter.jc = 40
	
	self.jobs.big.jc = 50
	self.jobs.mia.jc = 40
	self.jobs.hox_3.jc = 30
	self.jobs.hox.jc = 50
	
	self.jobs.mad.jc = 50
	
	self.jobs.spa.jc = 40
	self.jobs.fish.jc = 50
	
	self.jobs.vit.jc = 90
	self.jobs.brb.jc = 30
	self.jobs.bph.jc = 60
	self.jobs.wwh.jc = 40
	self.jobs.tag.jc = 40
	self.jobs.pbr2.jc = 50
	self.jobs.pbr.jc = 60
	self.jobs.des.jc = 60
	self.jobs.sah.jc = 20

	self.jobs.crojob1.jc = 40
	self.jobs.crojob_wrapper.jc = 70
	self.jobs.friend.jc = 60
	
	self.jobs.election_day.jc = 30
	
	self.jobs.arm_wrapper.jc = 50
	self.jobs.bex.jc = 40
	
	self.jobs.haunted.jc = math.random(9) * 10
	self.jobs.nail.jc = math.random(9) * 10
	self.jobs.hvh.jc = math.random(9) * 10
	self.jobs.help.jc = math.random(9) * 10
	
	local rarity = {
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		1, 1, 1,
		2, 2,
		3, 
		4
	}

	self.jobs.branchbank_prof.jc = math.random(4, 5) * 10
	self.jobs.branchbank_gold_prof.jc = math.random(3, 5) * 10
	self.jobs.branchbank_cash.jc = math.random(2, 5) * 10
	self.jobs.branchbank_deposit.jc = math.random(4, 6) * 10
	self.jobs.kosugi_pro.jc = math.random(3, 6) * 10
	self.jobs.arm_cro.jc = math.random(5, 9) * 10
	self.jobs.arm_fac.jc = math.random(4, 7) * 10
	self.jobs.arm_hcm.jc = math.random(5, 7) * 10
	self.jobs.arm_par.jc = math.random(4, 7) * 10
	self.jobs.arm_und.jc = math.random(4, 7) * 10
	self.jobs.gallery.jc = math.random(3, 7) * 10
	self.jobs.kenaz.jc = math.random(6, 9) * 10
	self.jobs.rat.jc = math.random(4, 8) * 10

	self.jobs.run.jc = math.random(5, 9) * 10
	self.jobs.glace.jc = math.random(7, 9) * 10
	self.jobs.flat.jc = math.random(6, 9) * 10
	self.jobs.dah.jc = math.random(7, 9) * 10
	self.jobs.nmh.jc = math.random(5, 9) * 10
	self.jobs.red2.jc = math.random(4, 9) * 10
	self.jobs.man.jc = math.random(5, 9) * 10
	self.jobs.pal.jc = math.random(5, 9) * 10
	self.jobs.dinner.jc = math.random(5, 9) * 10
end
