function PlayerManager:verify_carry(peer, carry_id) return true end
function PlayerManager:verify_equipment(peer_id, equipment_id) return true end
function PlayerManager:verify_grenade(peer_id) return true end