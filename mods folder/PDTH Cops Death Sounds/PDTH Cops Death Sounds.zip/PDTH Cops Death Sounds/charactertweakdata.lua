Hooks:PostHook(CharacterTweakData, "init", "gugaga_init", function(self)
	self.swat.die_sound_event = "shd_x02a_any_3p_01"
	self.heavy_swat.die_sound_event = "bdz_x02a_any_3p"
	self.fbi_swat.die_sound_event = "shd_x02a_any_3p_01"
	self.fbi_heavy_swat.die_sound_event = "bdz_x02a_any_3p"
	self.city_swat.die_sound_event = "shd_x02a_any_3p_01"
	self.zeal_swat.die_sound_event = "shd_x02a_any_3p_01"
end)