Hooks:Add("LocalizationManagerPostInit", "HeistTesting_Localization_Eclipse", function(loc)
	LocalizationManager:add_localized_strings({
		["heist_airfield_hijack"] = "WHAT'S YOURS IS MINE",
		})
end)

-- ["heist_airfield_hijack_crimenet"] = "Vlad has returned from prison and needs some muscle to remind some people about who's still in charge around these parts, are you up for it? /nOBJECTIVES: /n> Shakedown downtown area stores for protection money. /n> Crash Mr. Stone's mall to make him pay up on missed out dues. /n> Ruin a wedding of a rival russian mob boss by stealing the bride's tiara /n> Finish up by putting the mob's nightclub out of business"
 
if not tweak_data then return end

tweak_data.narrative.jobs.airfield_hijack = {}
tweak_data.narrative.jobs.airfield_hijack.name_id = "heist_airfield_hijack"
tweak_data.narrative.jobs.airfield_hijack.contract_visuals = {}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.preview_image = { id = "firestarter_01" }
tweak_data.narrative.jobs.airfield_hijack.briefing_id = "heist_airfield_hijack_crimenet"
tweak_data.narrative.jobs.airfield_hijack.contact = "bain"
tweak_data.narrative.jobs.airfield_hijack.jc = 30
tweak_data.narrative.jobs.airfield_hijack.ghost_bonus = 0.1
tweak_data.narrative.jobs.airfield_hijack.campaign = false
tweak_data.narrative.jobs.airfield_hijack.professional = false
tweak_data.narrative.jobs.airfield_hijack.chain = {
		{
			level_id = "firestarter_1",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.airfield_hijack.briefing_event = { 
		""
}
tweak_data.narrative.jobs.airfield_hijack.debrief_event = {}
tweak_data.narrative.jobs.airfield_hijack.crimenet_callouts = {}
tweak_data.narrative.jobs.airfield_hijack.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.airfield_hijack.payout = { 95000 }
tweak_data.narrative.jobs.airfield_hijack.contract_cost = {
	24000,
	48000,
	120000,
	240000,
	300000,
	300000,
	300000
}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals = {}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

table.insert(tweak_data.narrative._jobs_index, "airfield_hijack")