Hooks:Add("LocalizationManagerPostInit", "HeistTesting_Localization_Eclipse", function(loc)
	LocalizationManager:add_localized_strings({
		["heist_turf_war_1"] = "FOUR STORES",
		["heist_turf_war_2"] = "MALLCRASHER",
		["heist_turf_war_3"] = "UKRAINIAN JOB",
		["heist_turf_war_4"] = "NIGHTCLUB",
		["heist_turf_war"] = "Turf War",
		["heist_fbi_raid"] = "In The Dark",
		["heist_art_trading"] = "Art Trade",
		["heist_airfield_hijack"] = "Special Delivery",
		})
end)

-- ["heist_turf_war_crimenet"] = "Vlad has returned from prison and needs some muscle to remind some people about who's still in charge around these parts, are you up for it? /nOBJECTIVES: /n> Shakedown downtown area stores for protection money. /n> Crash Mr. Stone's mall to make him pay up on missed out dues. /n> Ruin a wedding of a rival russian mob boss by stealing the bride's tiara /n> Finish up by putting the mob's nightclub out of business"
 
if not tweak_data then return end

local marker_dot_color = Color(1, 1, 1)
local marker_dot_color_to = Color(1, 0.75, 0.75)

tweak_data.narrative.contacts.vlad_hidden = deep_clone(tweak_data.narrative.contacts.vlad)
tweak_data.narrative.contacts.bain_hidden = deep_clone(tweak_data.narrative.contacts.bain)
tweak_data.narrative.contacts.vlad_hidden.hidden = true
tweak_data.narrative.contacts.bain_hidden.hidden = true

-- == VLAD'S TURF WAR == --
tweak_data.narrative.jobs.turf_war = {}
tweak_data.narrative.jobs.turf_war.name_id = "heist_turf_war"
tweak_data.narrative.jobs.turf_war.contract_visuals = {}
tweak_data.narrative.jobs.turf_war.contract_visuals.preview_image = {
		id = "skm_big2",
		folder = "shl"
	}
tweak_data.narrative.jobs.turf_war.briefing_id = "heist_turf_war_crimenet"
tweak_data.narrative.jobs.turf_war.contact = "vlad_hidden"
tweak_data.narrative.jobs.turf_war.jc = 20
tweak_data.narrative.jobs.turf_war.campaign = true
tweak_data.narrative.jobs.turf_war.professional = false
tweak_data.narrative.jobs.turf_war.region = "professional"
tweak_data.narrative.jobs.turf_war.color_lerp = { speed = 10, from = marker_dot_color, to = marker_dot_color_to }
tweak_data.narrative.jobs.turf_war.chain = {
		{
			level_id = "four_stores",
			type_id = "heist_type_assault",
			type = "d",
		},
		{
			level_id = "mallcrasher",
			type_id = "heist_type_assault",
			type = "d"
		},
		{
			level_id = "ukrainian_job",
			type_id = "heist_type_assault",
			type = "d"
		},
		{
			level_id = "nightclub",
			type_id = "heist_type_assault",
			type = "d"
		}
}
tweak_data.narrative.jobs.turf_war.briefing_event = { 
		""
}
tweak_data.narrative.jobs.turf_war.debrief_event = "vld_nightclub_debrief"
tweak_data.narrative.jobs.turf_war.crimenet_callouts = {
		"vld_nightclub_cnc_01",
		"vld_ukranian_cnc_01",
		"vld_fourstores_cnc_01",
}
tweak_data.narrative.jobs.turf_war.crimenet_videos = {
		"cn_fours1",
		"cn_ukr1",
		"cn_nightc1",
}
tweak_data.narrative.jobs.turf_war.payout = { 150000 }
tweak_data.narrative.jobs.turf_war.contract_cost = {
	8000,
	16000,
	40000,
	80000,
	100000,
	100000,
	100000
}
tweak_data.narrative.jobs.turf_war.contract_visuals = {}
tweak_data.narrative.jobs.turf_war.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.turf_war.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

-- == FBI SERVER RAID == --
tweak_data.narrative.jobs.fbi_raid = {}
tweak_data.narrative.jobs.fbi_raid.name_id = "heist_fbi_raid"
tweak_data.narrative.jobs.fbi_raid.contract_visuals = {}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.preview_image = { icon = "firestarter_01" }
tweak_data.narrative.jobs.fbi_raid.briefing_id = "heist_fbi_raid_crimenet"
tweak_data.narrative.jobs.fbi_raid.contact = "bain_hidden"
tweak_data.narrative.jobs.fbi_raid.jc = 40
tweak_data.narrative.jobs.fbi_raid.ghost_bonus = 0.1
tweak_data.narrative.jobs.fbi_raid.campaign = false
tweak_data.narrative.jobs.fbi_raid.professional = false
tweak_data.narrative.jobs.fbi_raid.chain = {
		{
			level_id = "firestarter_2",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.fbi_raid.briefing_event = { 
		""
}
tweak_data.narrative.jobs.fbi_raid.debrief_event = {}
tweak_data.narrative.jobs.fbi_raid.crimenet_callouts = {}
tweak_data.narrative.jobs.fbi_raid.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.fbi_raid.payout = { 175000 }
tweak_data.narrative.jobs.fbi_raid.contract_cost = {
	8000,
	16000,
	40000,
	80000,
	100000,
	100000,
	100000
}
tweak_data.narrative.jobs.fbi_raid.contract_visuals = {}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

-- == MENDOZA AIRFIELD HEIST == --
tweak_data.narrative.jobs.airfield_hijack = {}
tweak_data.narrative.jobs.airfield_hijack.name_id = "heist_airfield_hijack"
tweak_data.narrative.jobs.airfield_hijack.contract_visuals = {}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.preview_image = { icon = "firestarter_01" }
tweak_data.narrative.jobs.airfield_hijack.briefing_id = "heist_airfield_hijack_crimenet"
tweak_data.narrative.jobs.airfield_hijack.contact = "bain_hidden"
tweak_data.narrative.jobs.airfield_hijack.jc = 30
tweak_data.narrative.jobs.airfield_hijack.ghost_bonus = 0.1
tweak_data.narrative.jobs.airfield_hijack.campaign = false
tweak_data.narrative.jobs.airfield_hijack.professional = false
tweak_data.narrative.jobs.airfield_hijack.chain = {
		{
			level_id = "firestarter_1",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.airfield_hijack.briefing_event = { 
		""
}
tweak_data.narrative.jobs.airfield_hijack.debrief_event = {}
tweak_data.narrative.jobs.airfield_hijack.crimenet_callouts = {}
tweak_data.narrative.jobs.airfield_hijack.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.airfield_hijack.payout = { 95000 }
tweak_data.narrative.jobs.airfield_hijack.contract_cost = {
	24000,
	48000,
	120000,
	240000,
	300000,
	300000,
	300000
}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals = {}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.airfield_hijack.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

-- == ART DEAL == --
tweak_data.narrative.jobs.art_trading = {}
tweak_data.narrative.jobs.art_trading.name_id = "heist_art_trading"
tweak_data.narrative.jobs.art_trading.contract_visuals = {}
tweak_data.narrative.jobs.art_trading.contract_visuals.preview_image = { icon = "gallery" }
tweak_data.narrative.jobs.art_trading.briefing_id = "heist_art_trading_crimenet"
tweak_data.narrative.jobs.art_trading.contact = "bain_hidden"
tweak_data.narrative.jobs.art_trading.jc = 30
tweak_data.narrative.jobs.art_trading.ghost_bonus = 0.05
tweak_data.narrative.jobs.art_trading.campaign = false
tweak_data.narrative.jobs.art_trading.professional = false
tweak_data.narrative.jobs.art_trading.chain = {
		{
			level_id = "gallery",
			type_id = "heist_type_stealth",
			type = "d",
		},
		{
			level_id = "framing_frame_2",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.art_trading.briefing_event = { 
		""
}
tweak_data.narrative.jobs.art_trading.debrief_event = {}
tweak_data.narrative.jobs.art_trading.crimenet_callouts = {}
tweak_data.narrative.jobs.art_trading.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.art_trading.payout = { 95000 }
tweak_data.narrative.jobs.art_trading.contract_cost = {
	24000,
	48000,
	120000,
	240000,
	300000,
	300000,
	300000
}
tweak_data.narrative.jobs.art_trading.contract_visuals = {}
tweak_data.narrative.jobs.art_trading.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.art_trading.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

table.insert(tweak_data.narrative._jobs_index, "turf_war")
table.insert(tweak_data.narrative._jobs_index, "fbi_raid")
table.insert(tweak_data.narrative._jobs_index, "airfield_hijack")
table.insert(tweak_data.narrative._jobs_index, "art_trading")