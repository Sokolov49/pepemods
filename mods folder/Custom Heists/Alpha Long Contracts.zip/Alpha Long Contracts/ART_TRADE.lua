Hooks:Add("LocalizationManagerPostInit", "HeistTesting_Localization_Eclipse", function(loc)
	LocalizationManager:add_localized_strings({
		["heist_art_trading"] = "ART TRADE",
		})
end)

-- ["heist_art_trading_crimenet"] = "Vlad has returned from prison and needs some muscle to remind some people about who's still in charge around these parts, are you up for it? /nOBJECTIVES: /n> Shakedown downtown area stores for protection money. /n> Crash Mr. Stone's mall to make him pay up on missed out dues. /n> Ruin a wedding of a rival russian mob boss by stealing the bride's tiara /n> Finish up by putting the mob's nightclub out of business"
 
if not tweak_data then return end

tweak_data.narrative.jobs.art_trading = {}
tweak_data.narrative.jobs.art_trading.name_id = "heist_art_trading"
tweak_data.narrative.jobs.art_trading.contract_visuals = {}
tweak_data.narrative.jobs.art_trading.contract_visuals.preview_image = { id = "gallery" }
tweak_data.narrative.jobs.art_trading.briefing_id = "heist_art_trading_crimenet"
tweak_data.narrative.jobs.art_trading.contact = "bain"
tweak_data.narrative.jobs.art_trading.jc = 30
tweak_data.narrative.jobs.art_trading.ghost_bonus = 0.05
tweak_data.narrative.jobs.art_trading.campaign = false
tweak_data.narrative.jobs.art_trading.professional = false
tweak_data.narrative.jobs.art_trading.chain = {
		{
			level_id = "gallery",
			type_id = "heist_type_stealth",
			type = "d",
		},
		{
			level_id = "framing_frame_2",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.art_trading.briefing_event = { 
		""
}
tweak_data.narrative.jobs.art_trading.debrief_event = {}
tweak_data.narrative.jobs.art_trading.crimenet_callouts = {}
tweak_data.narrative.jobs.art_trading.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.art_trading.payout = { 95000 }
tweak_data.narrative.jobs.art_trading.contract_cost = {
	24000,
	48000,
	120000,
	240000,
	300000,
	300000,
	300000
}
tweak_data.narrative.jobs.art_trading.contract_visuals = {}
tweak_data.narrative.jobs.art_trading.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.art_trading.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

table.insert(tweak_data.narrative._jobs_index, "art_trading")