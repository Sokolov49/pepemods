Hooks:Add("LocalizationManagerPostInit", "HeistTesting_Localization_Eclipse", function(loc)
	LocalizationManager:add_localized_strings({
		["heist_fbi_raid"] = "IN THE DARK",
		})
end)

-- ["heist_fbi_raid_crimenet"] = "Vlad has returned from prison and needs some muscle to remind some people about who's still in charge around these parts, are you up for it? /nOBJECTIVES: /n> Shakedown downtown area stores for protection money. /n> Crash Mr. Stone's mall to make him pay up on missed out dues. /n> Ruin a wedding of a rival russian mob boss by stealing the bride's tiara /n> Finish up by putting the mob's nightclub out of business"
 
if not tweak_data then return end

tweak_data.narrative.jobs.fbi_raid = {}
tweak_data.narrative.jobs.fbi_raid.name_id = "heist_fbi_raid"
tweak_data.narrative.jobs.fbi_raid.contract_visuals = {}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.preview_image = { id = "firestarter_01" }
tweak_data.narrative.jobs.fbi_raid.briefing_id = "heist_fbi_raid_crimenet"
tweak_data.narrative.jobs.fbi_raid.contact = "bain"
tweak_data.narrative.jobs.fbi_raid.jc = 40
tweak_data.narrative.jobs.fbi_raid.ghost_bonus = 0.1
tweak_data.narrative.jobs.fbi_raid.campaign = false
tweak_data.narrative.jobs.fbi_raid.professional = false
tweak_data.narrative.jobs.fbi_raid.chain = {
		{
			level_id = "firestarter_2",
			type_id = "heist_type_stealth",
			type = "d",
		}
}
tweak_data.narrative.jobs.fbi_raid.briefing_event = { 
		""
}
tweak_data.narrative.jobs.fbi_raid.debrief_event = {}
tweak_data.narrative.jobs.fbi_raid.crimenet_callouts = {}
tweak_data.narrative.jobs.fbi_raid.crimenet_videos = {
	"cn_branchbank1",
	"cn_branchbank2",
	"cn_branchbank3"
}
tweak_data.narrative.jobs.fbi_raid.payout = { 175000 }
tweak_data.narrative.jobs.fbi_raid.contract_cost = {
	8000,
	16000,
	40000,
	80000,
	100000,
	100000,
	100000
}
tweak_data.narrative.jobs.fbi_raid.contract_visuals = {}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.min_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}
tweak_data.narrative.jobs.fbi_raid.contract_visuals.max_mission_xp = {
	18000,
	18000,
	18000,
	18000,
	18000,
	18000,
	18000
}

table.insert(tweak_data.narrative._jobs_index, "fbi_raid")